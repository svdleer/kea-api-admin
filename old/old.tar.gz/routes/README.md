# Routes Directory

Note: All API routes are now defined in `/index.php`. The `routes/api.php` file is not currently used.