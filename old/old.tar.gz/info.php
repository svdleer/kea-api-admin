<?php
// Remove or comment out the phpinfo() call in production environments
// phpinfo();