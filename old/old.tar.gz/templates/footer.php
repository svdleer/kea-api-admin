    <footer class="bg-white shadow-lg mt-8">
        <div class="max-w-7xl mx-auto py-4 px-4">
            <p class="text-center text-gray-500">Kea DHCP Administration</p>
        </div>
    </footer>
</body>
</html>
