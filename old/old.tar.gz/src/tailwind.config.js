module.exports = {
  content: ['./views/login.php'],
  theme: {
    extend: {},
  },
  plugins: [],
};
