<?php

namespace App\Models;

use PDO;
use Exception;


class DHCP
{
    private $db;
    private string $keaApiUrl;
    private string $keaService;


    public function __construct($db)
    {
        $this->db = $db;
        $this->keaApiUrl = $_ENV['KEA_API_ENDPOINT'];
        $this->keaService = 'dhcp6';
    }

    private function sendKeaCommand($command, $arguments = [])
    {
        $data = [
            
            "command" => $command,
            "service" => [$this->keaService],
            "arguments" => $arguments
        ];

        $ch = curl_init($this->keaApiUrl);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

        $response = curl_exec($ch);
        if (curl_errno($ch)) {
            throw new Exception('Kea API Error: ' . curl_error($ch));
        }
        curl_close($ch);

        return json_decode($response, true);
    }


    private function getNextAvailableSubnetId()
    {
        error_log("DHCP Model: Starting getNextAvailableSubnetId");
        try {
            // Get current configuration
            error_log("DHCP Model: Sending config-get command to Kea");
            $response = $this->sendKeaCommand('config-get');
            error_log("DHCP Model: Received response from Kea: " . json_encode($response));
            
            if (!isset($response[0]['result']) || $response[0]['result'] !== 0) {
                error_log("DHCP Model: Invalid response from Kea - result not 0 or missing");
                throw new Exception("Failed to get configuration from Kea");
            }

            $config = $response[0]['arguments'];
            error_log("DHCP Model: Extracted config arguments: " . json_encode($config));
            
            $subnets = $config['Dhcp6']['subnet6'] ?? [];
            error_log("DHCP Model: Found " . count($subnets) . " subnets in configuration");

            // Get all existing subnet IDs
            $existingIds = [];
            foreach ($subnets as $subnet) {
                if (isset($subnet['id'])) {
                    $existingIds[] = (int)$subnet['id'];
                    error_log("DHCP Model: Found subnet ID: " . $subnet['id']);
                }
            }

            // If no subnets exist, start with ID 1
            if (empty($existingIds)) {
                error_log("DHCP Model: No existing subnets found, returning ID 1");
                return 1;
            }

            // Find the next available ID
            sort($existingIds);
            error_log("DHCP Model: Sorted existing IDs: " . json_encode($existingIds));
            $maxId = end($existingIds);
            error_log("DHCP Model: Maximum existing ID: " . $maxId);
            
            // Look for gaps in the sequence
            $previousId = 0;
            error_log("DHCP Model: Searching for gaps in ID sequence");
            foreach ($existingIds as $id) {
                error_log("DHCP Model: Checking ID: " . $id . " (previous: " . $previousId . ")");
                if ($id > $previousId + 1) {
                    $nextId = $previousId + 1;
                    error_log("DHCP Model: Found gap, returning ID: " . $nextId);
                    return $nextId;
                }
                $previousId = $id;
            }

            // If no gaps found, return max + 1
            $nextId = $maxId + 1;
            error_log("DHCP Model: No gaps found, returning max+1: " . $nextId);
            return $nextId;

        } catch (Exception $e) {
            error_log("DHCP Model: Error in getNextAvailableSubnetId: " . $e->getMessage());
            error_log("DHCP Model: Stack trace: " . $e->getTraceAsString());
            throw $e;
        }
    }

    public function hasDHCPSubnetsForBVI($bviInterfaceId)
    {
        $subnets = $this->getEnrichedSubnets();
        foreach ($subnets as $subnet) {
                error_log( "BVI ".$subnet['bvi_interface_id'] );
                error_log("DHCP Model: Checking subnet: " . json_encode($subnet));
            if ($subnet['bvi_interface_id'] == $bviInterfaceId) {  
                return true;
            }
        }
        
        return false;
    }

    public function hasDHCPSubnetsForSwitch($switchId)
    {
        $subnets = $this->getEnrichedSubnets();
        
        foreach ($subnets as $subnet) {
            if ($subnet['switch_id'] == $switchId) {
                return true;
            }
        }
        
        return false;
    }

    
    public function createSubnet($data)
    {
        error_log("DHCP Model: ====== Starting createSubnet ======");
        error_log("DHCP Model: Received data: " . json_encode($data, JSON_PRETTY_PRINT));
        error_log("DHCP Model: Data type: " . gettype($data));
        try {
            $subnetId = $this->getNextAvailableSubnetId();
            
            $arguments = [
                "remote" => [
                    "type" => "mysql"
                ],
                "server-tags" => ["all"],
                "subnets" => [
                    [
                        "subnet" => $data['subnet'],
                        "id" => $subnetId,
                        "shared-network-name" => null,
                        "pools" => [
                            [
                                "pool" => $data['pool_start'] . " - " . $data['pool_end']
                            ]
                        ],
                        "relay" => [
                            "ip-addresses" => [$data['relay_address']]
                        ],
                        "option-data" => [
                            [
                                "name" => "ccap-core",
                                "code" => 61,
                                "space" => "vendor-4491",
                                "csv-format" => true,
                                "data" => $data['ccap_core_address'],
                                "always-send" => true
                            ]
                        ]
                    ]
                ]
            ];
    
            error_log("DHCP Model: Remote-subnet-set arguments prepared: " . json_encode($arguments));
    
            $response = $this->sendKeaCommand('remote-subnet6-set', $arguments);
            error_log("DHCP Model: Kea response received: " . json_encode($response));
    
            if (!isset($response[0]['result']) || $response[0]['result'] !== 0) {
                error_log("DHCP Model: Remote-subnet-set command failed");
                throw new Exception("Failed to set remote subnet: " . json_encode($response));
            }
    
            // After successful KEA subnet creation, store in database
            $sql = "REPLACE INTO cin_bvi_dhcp_core (
                        switch_id, 
                        kea_subnet_id, 
                        interface_number, 
                        ipv6_address, 
                        start_address, 
                        end_address, 
                        ccap_core
                    ) VALUES (
                        :switch_id,
                        :kea_subnet_id,
                        :interface_number,
                        :ipv6_address,
                        :start_address,
                        :end_address,
                        :ccap_core
                    )";
    
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                ':switch_id' => $data['switch_id'],
                ':kea_subnet_id' => $subnetId,
                ':interface_number' => $data['bvi_interface'],
                ':ipv6_address' => $data['ipv6_address'],
                ':start_address' => $data['pool_start'],
                ':end_address' => $data['pool_end'],
                ':ccap_core' => $data['ccap_core_address']
            ]);
    
            error_log("DHCP Model: Remote subnet set successfully");
            return $subnetId;
    
        } catch (Exception $e) {
            error_log("DHCP Model: Error occurred while setting remote subnet: " . $e->getMessage());
            throw $e;
        }
    }

    public function updateSubnet($data)
    {
        error_log("DHCP Model: ====== Starting updateSubnet ======");
        error_log("DHCP Model: Received data: " . json_encode($data, JSON_PRETTY_PRINT));
        error_log("DHCP Model: Data type: " . gettype($data));
        try {
            
            $arguments = [
                "remote" => [
                    "type" => "mysql"
                ],
                "server-tags" => ["all"],
                "subnets" => [
                    [
                        "subnet" => $data['subnet'],
                        "id" => intval($data['subnet_id']),
                        "shared-network-name" => null,
                        "pools" => [
                            [
                                "pool" => $data['pool_start'] . " - " . $data['pool_end']
                            ]
                        ],
                        "relay" => [
                            "ip-addresses" => [$data['relay_address']]
                        ],
                        "option-data" => [
                            [
                                "name" => "ccap-core",
                                "code" => 61,
                                "space" => "vendor-4491",
                                "csv-format" => true,
                                "data" => $data['ccap_core_address'],
                                "always-send" => true
                            ]
                        ]
                    ]
                ]
            ];
    
            error_log("DHCP Model: Remote-subnet-set arguments prepared: " . json_encode($arguments));
    
            $response = $this->sendKeaCommand('remote-subnet6-set', $arguments);
            error_log("DHCP Model: Kea response received: " . json_encode($response));
    
            if (!isset($response[0]['result']) || $response[0]['result'] !== 0) {
                error_log("DHCP Model: Remote-subnet-set command failed");
                throw new Exception("Failed to set remote subnet: " . json_encode($response));
            }
    
            // After reconfigurering KEA subnet creation, update in database
            $sql = "INSERT INTO cin_bvi_dhcp_core (
                switch_id, 
                kea_subnet_id, 
                interface_number, 
                ipv6_address, 
                start_address, 
                end_address, 
                ccap_core
            ) VALUES (
                :switch_id,
                :kea_subnet_id,
                :interface_number,
                :ipv6_address,
                :start_address,
                :end_address,
                :ccap_core
            ) ON DUPLICATE KEY UPDATE 
                kea_subnet_id = VALUES(kea_subnet_id),
                ipv6_address = VALUES(ipv6_address),
                start_address = VALUES(start_address),
                end_address = VALUES(end_address),
                ccap_core = VALUES(ccap_core)";
    
    
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                ':switch_id' => $data['switch_id'],
                ':kea_subnet_id' => $data['subnet_id'],
                ':interface_number' => $data['bvi_interface'],
                ':ipv6_address' => $data['ipv6_address'],
                ':start_address' => $data['pool_start'],
                ':end_address' => $data['pool_end'],
                ':ccap_core' => $data['ccap_core_address']
            ]);
    
            error_log("DHCP Model: Remote subnet reconfigured successfully");
            return $data['subnet_id'];
    
        } catch (Exception $e) {
            error_log("DHCP Model: Error occurred while reconfigering remote subnet: " . $e->getMessage());
            throw $e;
        }
    }



    public function deleteSubnet($subnetId)
    {
        try {
            $arguments = [
                "remote" => [
                    "type" => "mysql"
                ],
                "subnets" => [
                    [
                        "id" => intval($subnetId)
                    ]
                ]
            ];
    
            error_log("DHCP Model: Attempting to delete subnet with ID: " . $subnetId);
            
            $response = $this->sendKeaCommand('remote-subnet6-del-by-id', $arguments);
            error_log("DHCP Model: Kea response received: " . json_encode($response));
    
            // Check if response is valid and deletion was successful
            if (!isset($response[0]['result']) || $response[0]['result'] !== 0 || 
                !isset($response[0]['arguments']['count']) || $response[0]['arguments']['count'] === 0) {
                error_log("DHCP Model: Delete subnet command failed");
                throw new Exception("Failed to delete subnet: " . ($response[0]['text'] ?? 'Unknown error'));
            }
    
            error_log("DHCP Model: Successfully deleted subnet. Response text: " . $response[0]['text']);
            error_log("DHCP Model: Cleaning up cin_bvi_dhcp_core table");
            
            $sql = "UPDATE cin_bvi_dhcp_core 
                    SET kea_subnet_id = NULL,
                        start_address = NULL,
                        end_address = NULL,
                        ccap_core = NULL,
                        updated_at = NOW()
                    WHERE kea_subnet_id = :subnet_id";

            $stmt = $this->db->prepare($sql);
            $stmt->execute([':subnet_id' => $subnetId]);
            
            $rowsAffected = $stmt->rowCount();
            error_log("DHCP Model: Updated {$rowsAffected} rows in cin_bvi_dhcp_core table");

            error_log("DHCP Model: ====== Completed deleteSubnet successfully ======");
            return true;
    
        } catch (Exception $e) {
            error_log("DHCP Model: Error occurred while deleting subnet: " . $e->getMessage());
            throw $e;
        }
    }


    public function getAllSubnetsfromKEA()
    {
        error_log("DHCP Model: ====== Starting getAllSubnets ======");
        
        try {
            error_log("DHCP Model: Preparing arguments for KEA command");
            $arguments = [
                "remote" => [
                    "type" => "mysql"
                ],
                "server-tags" => ["all"],
            ];
    
            error_log("DHCP Model: Arguments prepared: " . json_encode($arguments));
            
            error_log("DHCP Model: Sending remote-subnet6-list command to KEA");
            $response = $this->sendKeaCommand('remote-subnet6-list', $arguments);
            error_log("DHCP Model: Response type: " . gettype($response));
            error_log("DHCP Model: Raw response: " . json_encode($response));
    
            if (!is_array($response) || empty($response) || !isset($response[0])) {
                error_log("DHCP Model: ERROR - Invalid response format");
                return [];
            }
    
            $firstResponse = $response[0];
    
            if (!isset($firstResponse['result'])) {
                error_log("DHCP Model: ERROR - Result code missing in response");
                throw new Exception("Missing result code in KEA response");
            }
    
            // Check if it's a valid "no subnets" response
            if ($firstResponse['result'] === 3 && 
                isset($firstResponse['arguments']['count']) && 
                $firstResponse['arguments']['count'] === 0) {
                error_log("DHCP Model: No subnets found (valid empty response)");
                return [];
            }
    
            // For other non-zero results, throw an exception
            if ($firstResponse['result'] !== 0) {
                error_log("DHCP Model: ERROR - Non-zero result code: " . $firstResponse['result']);
                throw new Exception("Failed to get subnets: " . json_encode($response));
            }
    
            $subnets = $firstResponse['arguments']['subnets'] ?? [];
            error_log("DHCP Model: Number of subnets retrieved: " . count($subnets));
            
            if (!empty($subnets)) {
                error_log("DHCP Model: First subnet example: " . json_encode($subnets[0]));
            }
    
            error_log("DHCP Model: ====== Completed getAllSubnets successfully ======");
            return $subnets;
    
        } catch (Exception $e) {
            error_log("DHCP Model: ====== ERROR in getAllSubnets ======");
            error_log("DHCP Model: Exception message: " . $e->getMessage());
            error_log("DHCP Model: Exception trace: " . $e->getTraceAsString());
            throw $e;
        }
    }
    
      

    public function getEnrichedSubnets()
    {
        error_log("DHCP Model: ====== Starting getEnrichedSubnets ======");
        
        try {
            $keaResponse = $this->getAllSubnetsfromKEA();
            error_log("DHCP Model: Raw response data: " . json_encode($keaResponse));

            // If we get null or empty array from getAllSubnetsfromKEA, return empty array
            if (empty($keaResponse)) {
                error_log("DHCP Model: No subnets found in KEA response");
                error_log("DHCP Model: ====== Completed getEnrichedSubnets. Total subnets: 0 ======");
                return [];
            }

            // Ensure we have valid subnets to process
            if (!is_array($keaResponse)) {
                error_log("DHCP Model: Invalid response format from KEA");
                return [];
            }

            error_log("DHCP Model: Processing " . count($keaResponse) . " subnets");

            $enrichedSubnets = [];
            foreach ($keaResponse as $subnet) {
                if (!is_array($subnet)) {
                    error_log("DHCP Model: Invalid subnet data, skipping");
                    continue;
                }

                error_log("DHCP Model: Processing subnet: " . json_encode($subnet));
                
                // Map the database fields to our expected structure
                $subnetId = $subnet['id'] ?? 'unknown';
                error_log("DHCP Model: Processing subnet ID: " . $subnetId);
                
                // Get custom configuration
                error_log("DHCP Model: Getting custom config for subnet " . $subnetId);
                $customConfig = $this->getBVIConfig($subnetId);
                error_log("DHCP Model: Custom config received: " . json_encode($customConfig));

                // Extract pool information from the subnet data
                $poolStart = '';
                $poolEnd = '';
                if (isset($subnet['pools']) && is_array($subnet['pools']) && !empty($subnet['pools'])) {
                    $poolParts = explode('-', $subnet['pools'][0]['pool'] ?? '');
                    $poolStart = $poolParts[0] ?? '';
                    $poolEnd = $poolParts[1] ?? '';
                }

                $enrichedSubnet = [
                    'id' => $subnetId,
                    'subnet' => $subnet['subnet'] ?? '',
                    'pool' => [
                        'start' => $customConfig['start_address'] ?? $poolStart,
                        'end' => $customConfig['end_address'] ?? $poolEnd
                    ],
                    'bvi_interface' => $customConfig['interface_number'] ?? null,
                    'bvi_interface_id' => $customConfig['id'] ?? null,
                    'ccap_core' => $customConfig['ccap_core'] ?? null,
                    'ipv6_address' => $customConfig['ipv6_address'] ?? null,
                    'switch_id' => $customConfig['switch_id'] ?? null,
                    'created_at' => $customConfig['created_at'] ?? null,
                    'updated_at' => $customConfig['updated_at'] ?? null
                ];
                
                error_log("DHCP Model: Enriched subnet data: " . json_encode($enrichedSubnet));
                $enrichedSubnets[] = $enrichedSubnet;
            }

            error_log("DHCP Model: ====== Completed getEnrichedSubnets. Total subnets: " . count($enrichedSubnets) . " ======");
            return $enrichedSubnets;

        } catch (Exception $e) {
            error_log("DHCP Model: ====== ERROR in getEnrichedSubnets ======");
            error_log("DHCP Model: Exception message: " . $e->getMessage());
            error_log("DHCP Model: Exception trace: " . $e->getTraceAsString());
            throw $e;
        }
    }
    
    private function getBVIConfig($subnetId)
    {
        $stmt = $this->db->prepare("
            SELECT * FROM cin_bvi_dhcp_core 
            WHERE kea_subnet_id = ?
        ");
        $stmt->execute([$subnetId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getAllSubnets() {
        $query = "SELECT 
            s.subnet_id,
            s.subnet_prefix,
            c.bvi_interface_id,
            p.start_address as pool_start,
            p.end_address as pool_end,
            c.ccap_core_address
        FROM dhcp6_subnet s
        LEFT JOIN dhcp6_pool p ON s.subnet_id = p.subnet_id
        LEFT JOIN custom_dhcp6_subnet_config c ON s.subnet_id = c.subnet_id";
    
        try {
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (\PDOException $e) {
            error_log("Error fetching subnets: " . $e->getMessage());
            return [];
        }
    }

    public function beginTransaction()
    {
        return $this->db->beginTransaction();
    }

    public function commit()
    {
        return $this->db->commit();
    }

    public function rollback()
    {
        return $this->db->rollBack();
    }

    public function checkDuplicateSubnet($subnet, $excludeId = null)
    {
        $query = "SELECT subnet_id FROM dhcp6_subnet WHERE subnet_prefix = :subnet";
        $params = ['subnet' => $subnet];
    
        if ($excludeId) {
            $query .= " AND subnet_id != :exclude_id";
            $params['exclude_id'] = $excludeId;
        }
    
        $stmt = $this->db->prepare($query);
        $stmt->execute($params);
        
        return $stmt;  
    }
    
    public function getSubnetById($subnetId)
    {
        try {
            $arguments = [
                "remote" => [
                    "type" => "mysql"
                ],
                "subnets" => [
                    [
                        "id" => intval($subnetId)
                    ]
                ]
            ];
    
            error_log("DHCP Model: Getting subnet by ID: " . $subnetId);
            
            $response = $this->sendKeaCommand('remote-subnet6-get-by-id', $arguments);
            error_log("DHCP Model: Kea response received: " . json_encode($response));
    
            // Check if response is valid and has count > 0
            if (!isset($response[0]['result']) || $response[0]['result'] !== 0 || 
                !isset($response[0]['arguments']['count']) || $response[0]['arguments']['count'] === 0) {
                error_log("DHCP Model: Get subnet by ID command failed or no subnet found");
                return null;
            }
    
            $subnet = $response[0]['arguments']['subnets'][0];
            
            // Format the response with the specific fields we need
            return [
                'id' => $subnet['id'],
                'subnet' => $subnet['subnet'],
                'pools' => array_map(function($pool) {
                    return [
                        'pool_start' => explode('-', $pool['pool'])[0],
                        'pool_end' => explode('-', $pool['pool'])[1]
                    ];
                }, $subnet['pools']),
                'relay_addresses' => $subnet['relay']['ip-addresses'] ?? [],
                'shared_network_name' => $subnet['shared-network-name'],
                'option_data' => $subnet['option-data']
            ];
    
        } catch (Exception $e) {
            error_log("DHCP Model: Error occurred while getting subnet by ID: " . $e->getMessage());
            throw $e;
        }
    }
    
    


    private function deleteSubnetFromDatabase($subnet_id)
    {
        try {
            // Delete from custom_dhcp6_subnet_config
            $query1 = "DELETE FROM custom_dhcp6_subnet_config WHERE subnet_id = :subnet_id";
            $stmt1 = $this->db->prepare($query1);
            $stmt1->execute(['subnet_id' => $subnet_id]);
    
            /*
            // Delete from dhcp6_pool
            $query2 = "DELETE FROM dhcp6_pool WHERE subnet_id = :subnet_id";
            $stmt2 = $this->db->prepare($query2);
            $stmt2->execute(['subnet_id' => $subnet_id]);
    
            // Delete from dhcp6_subnet
            $query3 = "DELETE FROM dhcp6_subnet WHERE subnet_id = :subnet_id";
            $stmt3 = $this->db->prepare($query3);
            $stmt3->execute(['subnet_id' => $subnet_id]);
            */
    
            return true;
        } catch (PDOException $e) {
            throw new Exception("Database error: " . $e->getMessage());
        }
    }
    
        
    

}
